from django.apps import AppConfig


class OrderManagerConfig(AppConfig):
    name = 'order_manager'
    verbose_name = "订单管理"
