from django.apps import AppConfig


class ShopManagerConfig(AppConfig):
    name = 'shop_manager'
    verbose_name = "门店管理"
