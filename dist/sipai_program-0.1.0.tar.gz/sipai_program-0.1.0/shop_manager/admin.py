from django.contrib import admin

# Register your models here.
# import xadmin
# from .models import City, Shop, SymptomCategory, MassageProgram, Technician
#
# xadmin.site.register(City)
# xadmin.site.register(Shop)
# xadmin.site.register(SymptomCategory)
# xadmin.site.register(MassageProgram)
# xadmin.site.register(Technician)