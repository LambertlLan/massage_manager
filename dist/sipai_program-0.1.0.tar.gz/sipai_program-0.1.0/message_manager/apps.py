from django.apps import AppConfig


class MessageManagerConfig(AppConfig):
    name = 'message_manager'
    verbose_name = "消息管理"
