from django.apps import AppConfig


class UserManagerConfig(AppConfig):
    name = 'user_manager'
    verbose_name = "用户管理"
