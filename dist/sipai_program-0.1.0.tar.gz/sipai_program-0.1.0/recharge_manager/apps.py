from django.apps import AppConfig


class RechargeManagerConfig(AppConfig):
    name = 'recharge_manager'
    verbose_name = "充值记录"
