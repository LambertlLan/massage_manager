from django.apps import AppConfig


class VouchersManagerConfig(AppConfig):
    name = 'vouchers_manager'
    verbose_name = "代金券管理"
